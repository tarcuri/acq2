#!/usr/bin/env python

import sqlite3

# Python generator function to parse tokens from file stream
def read_tokens(f):
    for line in f:
        for token in line.split():
            yield token

def get_next_command(f):
    tokens = read_tokens(f)
    cmd = ""
    for t in tokens:
        cmd += t + " "
        if t.endswith(";"):
            return cmd
    # error, no closing ';'
    return ""

def exec_sql_command(conn, cmd):
    c = conn.cursor()
    try:
        c.execute(cmd)
    except sqlite3.Error, e:
        print "An SQL error occurred:", e.args[0]
        print ">>> ", cmd
    conn.commit()
    c.close()

if __name__ == '__main__':
	# load schema file
    input_file = open("andro_jets.schema", 'r')
    conn = sqlite3.connect("andro_jets.sqlite")
    cmd = get_next_command(input_file)
    while cmd:
        exec_sql_command(conn, cmd)
        cmd = get_next_command(input_file)
    conn.close()
