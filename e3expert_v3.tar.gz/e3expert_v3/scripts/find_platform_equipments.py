#!/usr/bin/env python

import sqlite3
import sys

def print_platform_equipment(conn, plf):
    c = conn.cursor()
    # print platform nomenclature
    sql = "SELECT NOMENCLATURE_TEXT FROM NOMENCLATURE WHERE EQUIPMENT_ID = \'%s\'" % plf
    c.execute(sql)
    platform_name = c.fetchall()
    for p in platform_name:
        print "%s:" % p,
    # type
    sql = "SELECT PLATFORM_TYPE_CODE FROM PLATFORM WHERE RECORD_ID = \'%s\'" % plf
    c.execute(sql)
    type = c.fetchall()
    print "TYPE: %s" % type[0]
    print
    # get linked equipments from PLATFORM_EQUIPMENT_LINK
    sql = "SELECT EQUIPMENT_RECORD_ID FROM PLATFORM_EQUIPMENT_LINK WHERE PLATFORM_RECORD_ID = \'%s\'" % plf
    c.execute(sql)
    equips = c.fetchall()
    c.close()
    for eq in equips:
        print_equipment_info(conn, eq)

def print_equipment_info(conn, eq):
    sql = "SELECT NOMENCLATURE_TEXT FROM NOMENCLATURE WHERE EQUIPMENT_ID = \'%s\'" % eq
    c = conn.cursor()
    c.execute(sql)
    eq_name = c.fetchall()
    for name in eq_name:
        print "  (%s) %s:" % (eq[0],name[0])
        sql = "SELECT DESCRIPTION_TEXT FROM DESCRIPTION WHERE EQUIPMENT_ID = \'%s\'" % eq
        c.execute(sql)
        desc = c.fetchall()
        for d in desc:
            print "\t%s |" % d

if __name__ == '__main__':
    conn = sqlite3.connect("andro_jets.sqlite")

    if len(sys.argv) == 1:
        plf = "PLF1633"	# F-5F TIGER II
    else:
        plf = sys.argv[1]
    print "searching platform %s..." % plf
    print
    print_platform_equipment(conn, plf)
    conn.close()
