#!/usr/bin/env python

import sqlite3

def get_table_list(conn):
    q = "SELECT name FROM sqlite_master WHERE type=\'table\'"
    c = conn.cursor()
    table_list = []
    for row in c.execute(q):
        table_list.append(row[0])
    conn.commit()
    c.close()
    table_list.sort()
    return table_list

def get_column_names(conn, table_name):
    c = conn.cursor()
    c.execute("PRAGMA table_info(%s)" % table_name)
    cols = c.fetchall()
    col_names = []
    for col in cols:
        col_names.append(col[1])
    c.close()
    return col_names

def remove_extra_columns(col_names, orig_header, params):
    ncols = len(col_names)
    norig = len(orig_header)
    if norig != len(params):
        return None
    ci = 0
    new_params = []
    for i in range(norig):
        if ci >= ncols:
            break
        if orig_header[i] == col_names[ci]:
            new_params.append(params[i])
            ci += 1
            if ci >= ncols:
                break
        else:
            #print "stripping ", orig_header[i]
            pass
    return new_params

# TODO: need to sanitize database input (commas, parentheses, etc)o
#       also need to make sure params are quoted properly

# need to strip out unused values (BIB, CLS, etc)
def populate_table(conn, table_name):
    try:
        f = open("jets/%s.txt" % table_name, 'r')
    except IOError:
        return
    c = conn.cursor()
    orig_header = f.readline().replace('\n','').replace('\r','').split("|")
    col_names = get_column_names(conn, table_name)
    # first line are field names, '|' delimited
    r = f.readline()
    # start a new transaction for each table
    while r:
        # get each field
        field_list = r.replace('\n','').replace('\r','').split("|")
        field_list_nulls = [x if x else "null" for x in field_list] # generators are awesome
        # insert into table
        params = remove_extra_columns(col_names, orig_header, field_list_nulls)
        if params == None:
            return
        param_var = ("?," * len(params))[:-1]
        sql = "INSERT INTO %s (%s) VALUES (%s)" % (table_name, ','.join(col_names), param_var)
        r = f.readline()
        try:
            c.execute(sql, params)
        except sqlite3.Error, e:
            print sql, ','.join(params)
            print "An SQL error occurred:", e.args[0]
    conn.commit()
    f.close()
    c.close()

if __name__ == '__main__':
    # get the list of tables from the newly created database
    conn = sqlite3.connect("andro_jets.sqlite")
    table_list = get_table_list(conn)
    for t in table_list:
        print t
        populate_table(conn, t)
    conn.close()
