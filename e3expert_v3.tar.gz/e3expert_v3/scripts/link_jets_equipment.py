#!/usr/bin/env python

import sqlite3

conn = sqlite3.connect("/home/tja/src/e3expert_plus/e3expert.db.sqlite")
c = conn.cursor()

# get list of all tables
c.execute("SELECT tbl_name FROM sqlite_master")
tables = c.fetchall()

equip_tables = []

# for each table, see if it has an EQUIPMENT_ID
for t in tables:
  c.execute("PRAGMA table_info('%s')" % t[0])
  cols = c.fetchall()
  for col in cols:
    if col[1] == 'EQUIPMENT_ID':
      equip_tables.append(t)
      break

equip_ids = []
f = open("jets_equip_ids.txt", 'w')

# build list of unique equipment IDs to test
print "Tables referencing EQUIPMENT_ID:"
for t in equip_tables:
  print "  %s" % t,
  f.write("%s\n" % t)
  q = "SELECT DISTINCT equipment_id FROM %s" % t
  c.execute(q)
  ids = c.fetchall()
  print "...%d IDs" % len(ids)
  for id in ids:
    if id not in equip_ids:
      equip_ids.append(id)

num_ids = len(equip_ids)
i = 0

print "Writing report to jets_equip_ids.txt...",

while i < num_ids:
    s = ""
    for j in range(5):
      if (i + j) < num_ids:
        s += "%s," % equip_ids[i+j]

    s = s[:-1]
    s += '\n'
    f.write(s)
    i += 5

f.close()

print "COMPLETE"
print "Found %d distinct equipment_id's" % len(equip_ids)
