#!/usr/bin/env python

import sqlite3

def query_execution(conn, id_list, profile_a, profile_b):
	x = conn.cursor()
	
	file_out = open("python_output.txt", "w")
	n = 0
	
	for i in id_list:
		sql = "SELECT "
				
		for c in profile_a:
			columns = get_columns(c)
			if len(columns) != 0:
				for cons in columns:
					sql += "%s.%s, " % (c, cons)
					if n == 0:
						file_out.write("%s," % cons)
					
# 		for d in profile_b:
# 			columns = get_columns(d)
# 			if len(columns) != 0:
# 				for cons in columns:
# 					sql += "%s.%s, " % (d, cons)
					
		sql = sql[:-2]			
		sql += " FROM %s " % profile_a[0]
		
		for p in range(len(profile_a)-1):
			sql += "JOIN %s ON (%s.EQUIPMENT_ID = %s.EQUIPMENT_ID) " % (profile_a[p+1], profile_a[p], profile_a[p+1])
			
#		for q in range(len(profile_b)-1):
#			sql += "JOIN %s ON (%s. ) "
			
		sql += " WHERE NOMENCLATURE.EQUIPMENT_ID LIKE \"%s\" AND CONFIGURATION.CONFIG_ORD = 1.0 AND CONFIG_FREQ.CONFIG_ORD = 1.0 AND CONFIG_MODULATION.CONFIG_ORD = 1.0 AND SYSTEM_FUNCTION.CONFIG_ORD = 1.0 AND SYSTEM_DEPLOYMENT.CONFIG_ORD = 1.0" % i

#	SELECT NOMENCLATURE.NOMENCLATURE_TEXT, MAINTENANCE.ENTRY_DATE, CONFIGURATION.DESCRIPTION_TEXT, CONFIGURATION.EIRP_MAX_DBM, CONFIGURATION.EIRP_MIN_DBM, CONFIGURATION.SPECT_PWRDEN_MAX_DBWPERHZ, CONFIGURATION.SPECT_PWRDEN_MIN_DBWPERHZ, CONFIG_FREQ.CONFIG_FREQ_MAX_MHZ, CONFIG_FREQ.CONFIG_FREQ_MIN_MHZ, CONFIG_MODULATION.CONFIG_CCIR_TEXT FROM NOMENCLATURE JOIN MAINTENANCE ON (NOMENCLATURE.EQUIPMENT_ID = MAINTENANCE.EQUIPMENT_ID) JOIN CONFIGURATION ON (MAINTENANCE.EQUIPMENT_ID = CONFIGURATION.EQUIPMENT_ID) JOIN CONFIG_FREQ ON (CONFIGURATION.EQUIPMENT_ID = CONFIG_FREQ.EQUIPMENT_ID) JOIN CONFIG_MODULATION ON (CONFIG_FREQ.EQUIPMENT_ID = CONFIG_MODULATION.EQUIPMENT_ID) JOIN EQUIPMENT_AGENCY_LINK ON (CONFIG_MODULATION.EQUIPMENT_ID = EQUIPMENT_AGENCY_LINK.EQUIPMENT_ID) JOIN EQUIPMENT_MANUFACTURER_LINK ON (EQUIPMENT_AGENCY_LINK.EQUIPMENT_ID = EQUIPMENT_MANUFACTURER_LINK.EQUIPMENT_ID) JOIN SYSTEM_DEPLOYMENT ON (EQUIPMENT_MANUFACTURER_LINK.EQUIPMENT_ID = SYSTEM_DEPLOYMENT.EQUIPMENT_ID) JOIN SYSTEM_FUNCTION ON (SYSTEM_DEPLOYMENT.EQUIPMENT_ID = SYSTEM_FUNCTION.EQUIPMENT_ID) JOIN SYSTEM_GENERAL ON (SYSTEM_FUNCTION.EQUIPMENT_ID = SYSTEM_GENERAL.EQUIPMENT_ID)  WHERE NOMENCLATURE.EQUIPMENT_ID like "%41183S%" AND CONFIGURATION.CONFIG_ORD = 1.0 AND CONFIG_FREQ.CONFIG_ORD = 1.0 AND CONFIG_MODULATION.CONFIG_ORD = 1.0 AND SYSTEM_FUNCTION.CONFIG_ORD = 1.0 AND SYSTEM_DEPLOYMENT.CONFIG_ORD = 1.0
		
		x.execute(sql)
		data_out = x.fetchall()
		
		if n == 0:
			file_out.write("\n")
		n = 1
		for d1 in range(len(data_out)):
			for d2 in range(len(data_out[d1])):
				file_out.write("%s," % data_out[d1][d2])
			file_out.write("\n")
			
	file_out.close()	
	
def get_columns(table_name):
	if table_name == "AGENCY":
		cols = ["AGENCY_TEXT"]
	elif table_name == "CODES":
		cols = ["CODE_TEXT"]
	elif table_name == "CODES_COUNTRY":
		cols = ["COUNTRY_TEXT"]
	elif table_name == "CODES_LAUNCH_SITE":
		cols = ["LAUNCH_SITE_TEXT"]
	elif table_name == "CODES_ORBIT_TYPE":
		cols = ["ORBIT_TEXT"]
	elif table_name == "CODES_PLFTYPE":
		cols = ["TEXT"]
	elif table_name == "CODES_SAT_STATUS":
		cols = ["STATUS_TEXT"]
	elif table_name == "CODES_SYSTEM_DEPLOYMENT":
		cols = ["SYSTEM_DEPLOYMENT_TEXT"]
	elif table_name == "CONFIGURATION":
		cols = ["DESCRIPTION_TEXT", "EIRP_MAX_DBM", "EIRP_MIN_DBM", "SPECT_PWRDEN_MAX_DBWPERHZ", "SPECT_PWRDEN_MIN_DBWPERHZ"]
	elif table_name == "CONFIG_FREQ":
		cols = ["CONFIG_FREQ_MAX_MHZ", "CONFIG_FREQ_MIN_MHZ"]
	elif table_name == "CONFIG_MODULATION":
		cols = ["CONFIG_CCIR_TEXT"]
	elif table_name == "DESCRIPTION":
		cols = ["DESCRIPTION_TEXT"]
	elif table_name == "MAINTENANCE":
		cols = ["ENTRY_DATE"]
	elif table_name == "MANUFACTURER":
		cols = ["MANUFACTURER_LONG_TEXT"]
	elif table_name == "NOMENCLATURE":
		cols = ["NOMENCLATURE_TEXT"]
	elif table_name == "REMARK":
		cols = ["REMARK_TEXT"]
	elif table_name == "SATELLITE":
		cols = ["APOGEE_KM", "PERIGEE_KM", "ARGUMENT_OF_PERIGEE_DEG", "DRAG_COEFFICIENT_M2PERKG", 
				"EASTWEST_KEEPING_LIMITS_DEG", "NORTHSOUTH_KEEPING_LIMITS_DEG", "ECCENTRICITY",
				"ELEMENT_NUM", "EPOCH_DAY", "EPOCH_YEAR", "EPOCH_REVOLUTIONS", "FCC_CALL_SIGNS",
				"INCLINATION_ANGLE_DEG", "INCLINATION_EXCURSION_DEG", "INTERNATIONAL_DESIGNATOR",
				"LAUNCH_DATE", "MEAN_ANOMALY_DEG", "MEAN_MOT_REVPERDAY", "MEAN_MOT_1ST_DERIV_REVPERDAY2",
				"MEAN_MOT_2ND_DERIV_REVPERDAY3", "PERIOD_MINUTES", "RIGHT_ASCENSION_NODE_DEG",
				"SUBSATELLITE_HEIGHT_KM", "SUBSATELLITE_LAT_DEG", "SUBSATELLITE_LONG_DEG"]
	elif table_name == "SYSFUNCTEXT":
		cols = ["TEXT"]
	else:
		cols = []
		
	return cols

if __name__ == '__main__':
	conn = sqlite3.connect("andro_jets.sqlite")

	id_l = ["41183S", "40933S"]
	sys_profile_main = ["NOMENCLATURE", "MAINTENANCE", "CONFIGURATION", "CONFIG_FREQ", "CONFIG_MODULATION",
						"EQUIPMENT_AGENCY_LINK", "EQUIPMENT_MANUFACTURER_LINK", "SYSTEM_DEPLOYMENT", 
						"SYSTEM_FUNCTION", "SYSTEM_GENERAL"]
 	sys_profile_helper = ["EQUIPMENT_AGNECY_LINK", "AGENCY", "EQUIPMENT_MANUFACTURER_LINK", "MANUFACTURER",
 						  "MANUFACTURER_ID", "SYSTEM_DEPLOYMENT", "CODES_SYSTEM_DEPLOYMENT", "SYSTEM_DEPLOYMENT_CODE",
 						  "SYSTEM_FUNCTION", "SYSFUNCTEXT", "SYSTEM_FUNCTION_CODE"]
 	
#  						  "DESCRIPTION", "REMARK", "COMPLEX_SYSTEM_LINK", 
#  						  "PLATFORM_EQUIPMENT_LINK", "PLATFORM", "PLATFORM_LINK", "CODES_PLFTYPE",
#  						  "SATELLITE", "SATELLITE_SYSTEM_LINK", 
#  						  "CODES_COUNTRY", "CODES_LAUNCH_SITE", "CODES_ORBIT_TYPE", "CODES_SAT_STATUS",
#  						   
	
	query_execution(conn, id_l, sys_profile_main, sys_profile_helper)
	
	conn.close()