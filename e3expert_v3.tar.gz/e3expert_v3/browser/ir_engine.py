#!/usr/bin/env python

import sqlite3

def read_tokens(s):
	for token in s.split():
		yield token

class ir_engine:
	db_filenamne = "andro_jets.sqlite"
	kw_index = []
	tuples = []

	def __init__(self, db_file):
		if db_file:
			self.db_filename = db_file

		try:
			self.conn = sqlite3.connect(db_filename)
		except sqlite3.Error as e:
			print e.message

	def process_query(self, query):
		tokens = read_tokens(query)

		for kw in tokens:
			if kw not in kw_index:
				self.index_keyword(kw)

	def index_keyword(self, keyword):
		sql = "SELECT * FROM NOMENCLATURE_VIRT WHERE NOMENCLATURE_TEXT MATCH \'?\'"
		c = self.conn.cursor()
		try:
			c.execute(sql, keyword)
		except sqlite3.Error as e:
			print e.message

		hits = c.fetchall()
		for hit in hits:
			equip_id = hit[0]
		c.close()

	def get_results(self):
		return tuples
