#ifndef BROWSER_H
#define BROWSER_H

#include <boost/python.hpp>
//#include <boost/function.hpp>

#include <QTextStream>
#include <QSqlDatabase>
#include <QMainWindow>

namespace Ui {
class Browser;
}

namespace py = boost::python;

class Browser : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit Browser(QWidget *parent = 0);
    ~Browser();
    
private slots:
    void on_searchButton_clicked();

private:
    Ui::Browser *ui;

    QSqlDatabase _db;
    py::object se;
};

#endif // BROWSER_H
