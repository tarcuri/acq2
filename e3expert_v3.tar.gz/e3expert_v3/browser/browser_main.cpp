#include <QtGui/QApplication>
#include "browser.h"


